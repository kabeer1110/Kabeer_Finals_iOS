//
//  AppDelegate.m
// TheGame4
//
//  Created by Kabeer on 3/21/17.
//  Copyright © 2017 Kabeer. All rights reserved.
//

#import "AppDelegate.h"
#import "InitialViewController.h"


@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    InitialViewController *mainViewCon = [[InitialViewController alloc] init];
    self.window.rootViewController = mainViewCon;
    [self.window makeKeyAndVisible];
    return YES;
}

@end
