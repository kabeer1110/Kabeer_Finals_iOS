//
// BaseScene.h
// TheGame4
//
//  Created by Kabeer on 3/21/17.
//  Copyright © 2017 Kabeer. All rights reserved.
//


#import <SpriteKit/SpriteKit.h>

@interface BaseScene : SKScene

- (void)initalize;

@end
