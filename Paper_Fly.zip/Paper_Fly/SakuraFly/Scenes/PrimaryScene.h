//
// PrimaryScene.h
// TheGame4
//
//  Created by Kabeer on 3/21/17.
//  Copyright © 2017 Kabeer. All rights reserved.
//


#import "BaseScene.h"

@interface PrimaryScene : BaseScene

@property (nonatomic, assign) BOOL isGameStart;

@end
