//
// BaseScene.m
// TheGame4
//
//  Created by Kabeer on 3/21/17.
//  Copyright © 2017 Kabeer. All rights reserved.
//


#import "BaseScene.h"

@interface BaseScene()

@property (assign, nonatomic) BOOL contentCreated;

@end

@implementation BaseScene

- (void)didMoveToView:(SKView *)view
{
    if (_contentCreated) {
        return;
    }
    [self initalize];
    self.contentCreated = YES;
}

- (void)initalize
{
    NSLog(@"Base scene initalized");
}

@end
