//
// RestartLabel.h
// TheGame4
//
//  Created by Kabeer on 3/21/17.
//  Copyright © 2017 Kabeer. All rights reserved.
//


#import <SpriteKit/SpriteKit.h>

@class RestartLabel;

@protocol RestartViewDelegate <NSObject>

- (void)restartView:(RestartLabel *)restartView didPressRestartButton:(SKSpriteNode *)restartButton;
- (void)restartView:(RestartLabel *)restartView didPressLeaderboardButton:(SKSpriteNode *)restartButton;

@end

@interface RestartLabel : SKSpriteNode

@property (weak, nonatomic) id <RestartViewDelegate> delegate;
@property (copy, nonatomic) NSString* finalPoint;

+ (RestartLabel *)getInstanceWithSize:(CGSize)size Point:(NSString *)point;
- (void)dismiss;
- (void)showInScene:(SKScene *)scene;

@end
