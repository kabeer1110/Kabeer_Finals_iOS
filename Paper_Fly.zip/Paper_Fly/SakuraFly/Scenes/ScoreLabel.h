//
// ScoreLabel.h
// TheGame4
//
//  Created by Kabeer on 3/21/17.
//  Copyright © 2017 Kabeer. All rights reserved.
//


#import <SpriteKit/SpriteKit.h>

@interface ScoreLabel : SKSpriteNode

@property(nonatomic, copy) NSString* finalPoint;

@end
