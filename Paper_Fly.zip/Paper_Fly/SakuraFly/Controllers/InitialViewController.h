//
//  InitialViewController.h
// TheGame4
//
//  Created by Kabeer on 3/21/17.
//  Copyright © 2017 Kabeer. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <SpriteKit/SpriteKit.h>

@interface InitialViewController : UIViewController <UITextFieldDelegate, AVAudioPlayerDelegate>

@property (nonatomic, copy) NSString *leaderboardIdentifier;

-(void)showFullScreenAd;

@end
