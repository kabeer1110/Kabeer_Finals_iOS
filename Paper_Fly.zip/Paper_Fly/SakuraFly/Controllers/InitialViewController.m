//
// InitialViewController.m
// TheGame4
//
//  Created by Kabeer on 3/21/17.
//  Copyright © 2017 Kabeer. All rights reserved.
//

#import "InitialViewController.h"
#import "PrimaryScene.h"
#import "GameKitHeaders.h"

@import GameKit;

@interface InitialViewController ()

@property (strong, nonatomic) PrimaryScene *mainScene;

@end


@implementation InitialViewController

-(BOOL)prefersStatusBarHidden{
    return YES;
}

- (void)loadView
{
    CGRect applicationFrame = [[UIScreen mainScreen] applicationFrame];
    SKView *skView = [[SKView alloc] initWithFrame: applicationFrame];
    self.view = skView;
#ifdef DEBUG
    skView.showsDrawCount = YES;
    skView.showsFPS = YES;
    skView.showsNodeCount = YES;
#else
    [self authenticateLocalPlayer];
#endif
    _mainScene = [[PrimaryScene alloc] initWithSize:CGSizeMake(skView.bounds.size.width, skView.bounds.size.height)];
    _mainScene.scaleMode = SKSceneScaleModeAspectFit;
    [_mainScene runAction:[SKAction repeatActionForever:[SKAction playSoundFileNamed:@"backGround.mp3" waitForCompletion:YES]]];
    [skView presentScene:_mainScene];
}

@end
